package controller;

import database.DatabaseManager;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.util.StringConverter;
import org.mindrot.jbcrypt.BCrypt;
import utils.UserSession;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Optional;

/*
 * Controller Admin Panel
 * Gestioneaza:
 * 1. Angajati
 * 2. Utilizatori (ai aplicatiei)
 * 3. Login Logs
 */
public class AdminPanelController {

    // --- Elemente UI (FXML) ---
    @FXML private TableView<AngajatModel> angajatiTable;
    @FXML private TableColumn<AngajatModel, String> colAngNume, colAngPrenume, colAngFunctie, colAngTelefon, colAngEmail, colAngSupervisorName;
    @FXML private TableColumn<AngajatModel, Double> colAngSalariu;

    @FXML private TextField tfAngNume, tfAngPrenume, tfAngTelefon, tfAngEmail, tfAngSalariu;
    @FXML private ComboBox<String> cbAngFunctie;
    @FXML private ComboBox<AngajatModel> cbAngSupervisor;

    @FXML private TableView<UserModel> usersTable;
    @FXML private TableColumn<UserModel, String> colUserUser, colUserNume, colUserPrenume, colUserRol, colUserAngajatNume;

    @FXML private TextField tfUserUser, tfUserNume, tfUserPrenume;
    @FXML private PasswordField tfUserPass;
    @FXML private ComboBox<String> cbUserRol;
    @FXML private ComboBox<AngajatModel> cbUserLinkAngajat;
    @FXML private CheckBox chkUserExtern;

    @FXML private TableView<LogModel> logsTable;
    @FXML private TableColumn<LogModel, String> colLogUserTried, colLogDate, colLogStatus;

    // init ==> Se executa la deschiderea ferestrei
    @FXML
    public void initialize() {
        setupAngajatiTable();
        setupUsersTable();
        setupLogsTable();

        // Populam dropdown-urile cu valori statice
        cbAngFunctie.setItems(FXCollections.observableArrayList("Manager General", "Manager Evenimente", "Sef Ospatar", "Bucatar Sef", "Ospatar", "Barman", "DJ"));
        cbUserRol.setItems(FXCollections.observableArrayList("admin", "manager", "angajat", "test"));

        setupUserCreationLogic();
    }

    // Configurare tabel Angajati (legare coloane <-> model)
    private void setupAngajatiTable() {
        colAngNume.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().nume));
        colAngPrenume.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().prenume));
        colAngFunctie.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().functie));
        colAngTelefon.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().telefon));
        colAngEmail.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().email));
        colAngSalariu.setCellValueFactory(data -> new SimpleDoubleProperty(data.getValue().salariu).asObject());
        colAngSupervisorName.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().numeSupervizor));

        setupAngajatComboBox(cbAngSupervisor);
        refreshAngajati();
    }

    // Incarcare date Angajati din DB
    private void refreshAngajati() {
        ObservableList<AngajatModel> list = FXCollections.observableArrayList();

        // query 1 ////// SQL: SELECT + SELF JOIN ==> iau angajatii si numele sefului (din ID)
        String sql = "SELECT A.*, S.Nume AS SupNume, S.Prenume AS SupPrenume " +
                "FROM Angajati A " +
                "LEFT JOIN Angajati S ON A.IDSupervizor = S.IDAngajat";

        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                // Formatare string sef: "Nume Prenume (ID)"
                String supName = "-";
                if(rs.getInt("IDSupervizor") != 0) {
                    supName = rs.getString("SupNume") + " " + rs.getString("SupPrenume") + " (ID:" + rs.getInt("IDSupervizor") + ")";
                }

                list.add(new AngajatModel(
                        rs.getInt("IDAngajat"), rs.getString("Nume"), rs.getString("Prenume"),
                        rs.getString("Functie"), rs.getString("Telefon"), rs.getString("Email"),
                        rs.getDouble("Salariu"), rs.getInt("IDSupervizor"), supName
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }

        angajatiTable.setItems(list);
        cbAngSupervisor.setItems(list);
        cbUserLinkAngajat.setItems(list);
    }

    // Buton Adauga Angajat ==> Validare + Insert DB
    @FXML
    private void handleAddAngajat() {
        String nume = tfAngNume.getText().trim();
        String prenume = tfAngPrenume.getText().trim();
        String functie = cbAngFunctie.getValue();
        String telefon = tfAngTelefon.getText().trim();
        String email = tfAngEmail.getText().trim();
        String salariuStr = tfAngSalariu.getText().trim();

        // Validare: campuri goale
        if (nume.isEmpty() || prenume.isEmpty() || functie == null || telefon.isEmpty() || email.isEmpty() || salariuStr.isEmpty()) {
            showError("Toate campurile sunt obligatorii!");
            return;
        }

        // Validare: format telefon (07xxxxxxxx)
        if (!telefon.matches("^07\\d{8}$")) {
            showError("Numar de telefon invalid! Trebuie sa inceapa cu '07' si sa aiba 10 cifre.");
            return;
        }

        // Validare: format email
        if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            showError("Format Email invalid! Exemplu: angajat@ballroom.ro");
            return;
        }

        double salariu;
        try {
            salariu = Double.parseDouble(salariuStr);
            if (salariu <= 0) {
                showError("Salariul trebuie sa fie mai mare decat 0.");
                return;
            }
        } catch (NumberFormatException e) {
            showError("Salariul trebuie sa fie un numar valid (ex: 3500.50).");
            return;
        }

        // Confirmare user
        if (!showConfirmation("Sunteti sigur ca doriti sa adaugati acest angajat?")) {
            return;
        }

        try (Connection conn = DatabaseManager.getConnection();
             // SQL: INSERT ==> Adauga angajat nou
             PreparedStatement pstmt = conn.prepareStatement(
                     "INSERT INTO Angajati (Nume, Prenume, Functie, Telefon, Email, Salariu, IDSupervizor) VALUES (?,?,?,?,?,?,?)")) {

            pstmt.setString(1, nume);
            pstmt.setString(2, prenume);
            pstmt.setString(3, functie);
            pstmt.setString(4, telefon);
            pstmt.setString(5, email);
            pstmt.setDouble(6, salariu);

            // Setare sef (daca e selectat)
            AngajatModel supervisor = cbAngSupervisor.getValue();
            if(supervisor == null) pstmt.setObject(7, null);
            else pstmt.setInt(7, supervisor.id);

            pstmt.executeUpdate();
            refreshAngajati();
            clearAngajatiFields();
            showInfo("Angajat adaugat cu succes!");

        } catch (Exception e) { showError("Eroare la baza de date: " + e.getMessage()); }
    }

    // Buton Sterge Angajat ==> Tranzactie (Update Subalterni + Delete)
    @FXML
    private void handleDeleteAngajat() {
        AngajatModel sel = angajatiTable.getSelectionModel().getSelectedItem();
        if(sel == null) {
            showError("Selectati un angajat pentru a sterge.");
            return;
        }

        if (!showConfirmation("Sunteti sigur ca doriti sa stergeti angajatul " + sel.nume + " " + sel.prenume + "?")) {
            return;
        }

        Connection conn = null;
        try {
            conn = DatabaseManager.getConnection();
            conn.setAutoCommit(false); // Start Tranzactie

            // 1. SQL UPDATE: Subalternii raman fara sef (IDSupervizor = NULL)
            try (PreparedStatement updateStmt = conn.prepareStatement("UPDATE Angajati SET IDSupervizor = NULL WHERE IDSupervizor = ?")) {
                updateStmt.setInt(1, sel.id);
                updateStmt.executeUpdate();
            }

            // 2. SQL DELETE: Stergem angajatul
            try (PreparedStatement deleteStmt = conn.prepareStatement("DELETE FROM Angajati WHERE IDAngajat = ?")) {
                deleteStmt.setInt(1, sel.id);
                deleteStmt.executeUpdate();
            }

            conn.commit(); // Salvare modificari
            refreshAngajati();
            showInfo("Angajat sters cu succes! Subalternii au fost actualizati.");

        } catch (Exception e) {
            if (conn != null) {
                try { conn.rollback(); } catch (Exception ex) { ex.printStackTrace(); } // Anulare in caz de eroare
            }
            showError("Nu se poate sterge! Verificati daca angajatul are utilizator asociat.");
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); conn.close(); } catch (Exception e) { e.printStackTrace(); }
            }
        }
    }

    // Helper: Reset campuri angajat
    private void clearAngajatiFields() {
        tfAngNume.clear(); tfAngPrenume.clear(); tfAngTelefon.clear(); tfAngEmail.clear(); tfAngSalariu.clear();
        cbAngSupervisor.setValue(null);
    }

    // Configurare tabel Useri
    private void setupUsersTable() {
        colUserUser.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().username));
        colUserNume.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().nume));
        colUserPrenume.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().prenume));
        colUserRol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().rol));
        colUserAngajatNume.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().numeAngajatAsociat));

        setupAngajatComboBox(cbUserLinkAngajat);
        refreshUsers();
    }

    // Logica UI: Checkbox "User Extern" ==> Disable/Enable campuri
    private void setupUserCreationLogic() {
        chkUserExtern.selectedProperty().addListener((obs, wasSelected, isSelected) -> {
            if (isSelected) {
                // Extern ==> scriu manual nume/prenume
                cbUserLinkAngajat.setDisable(true);
                cbUserLinkAngajat.setValue(null);
                tfUserNume.setDisable(false);
                tfUserPrenume.setDisable(false);
                tfUserNume.clear();
                tfUserPrenume.clear();
            } else {
                // Angajat ==> aleg din lista
                cbUserLinkAngajat.setDisable(false);
                tfUserNume.setDisable(true);
                tfUserPrenume.setDisable(true);
            }
        });

        // Auto-complete: Select angajat ==> completare automata user/nume
        cbUserLinkAngajat.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !chkUserExtern.isSelected()) {
                tfUserNume.setText(newVal.nume);
                tfUserPrenume.setText(newVal.prenume);
                // Genereaza user: prenume.nume
                String generatedUser = (newVal.prenume + "." + newVal.nume).toLowerCase().replaceAll("\\s+", "");
                tfUserUser.setText(generatedUser);
            }
        });
    }

    // Incarcare Useri din DB
    private void refreshUsers() {
        ObservableList<UserModel> list = FXCollections.observableArrayList();
        // query 2 //// SQL: SELECT Useri + JOIN Angajati ==> sa vedem cine e userul in realitate
        String sql = "SELECT U.*, A.Nume AS AngNume, A.Prenume AS AngPrenume " +
                "FROM Utilizatori U " +
                "LEFT JOIN Angajati A ON U.IDAngajat = A.IDAngajat";

        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                String angajatInfo = "-";
                if(rs.getInt("IDAngajat") != 0) {
                    angajatInfo = rs.getString("AngNume") + " " + rs.getString("AngPrenume");
                }

                list.add(new UserModel(
                        rs.getInt("IDUtilizator"), rs.getString("Username"), rs.getString("Nume"),
                        rs.getString("Prenume"), rs.getString("Rol"), rs.getInt("IDAngajat"), angajatInfo
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        usersTable.setItems(list);
    }

    // Buton Adauga User ==> Insert + Hashing parola
    @FXML
    private void handleAddUser() {
        String username = tfUserUser.getText().trim();
        String password = tfUserPass.getText();
        String nume = tfUserNume.getText().trim();
        String prenume = tfUserPrenume.getText().trim();
        String rol = cbUserRol.getValue();

        // Validari input
        if (username.isEmpty() || password.isEmpty() || rol == null) {
            showError("Username, Parola si Rolul sunt obligatorii!");
            return;
        }

        if (username.length() < 3) {
            showError("Username-ul trebuie sa aiba minim 3 caractere.");
            return;
        }

        // Validare specifica extern vs angajat
        if (chkUserExtern.isSelected()) {
            if (nume.isEmpty() || prenume.isEmpty()) {
                showError("Pentru utilizatori externi, Numele si Prenumele sunt obligatorii!");
                return;
            }
        } else {
            if (cbUserLinkAngajat.getValue() == null) {
                showError("Selectati un angajat din lista SAU bifati 'Utilizator Extern'.");
                return;
            }
        }

        if (!showConfirmation("Sunteti sigur ca doriti sa creati utilizatorul " + username + "?")) {
            return;
        }

        try (Connection conn = DatabaseManager.getConnection();
             // SQL: INSERT ==> Creare user
             PreparedStatement pstmt = conn.prepareStatement(
                     "INSERT INTO Utilizatori (Username, ParolaHash, Nume, Prenume, Rol, IDAngajat) VALUES (?,?,?,?,?,?)")) {

            pstmt.setString(1, username);
            pstmt.setString(2, BCrypt.hashpw(password, BCrypt.gensalt())); // Hashing parola
            pstmt.setString(3, nume);
            pstmt.setString(4, prenume);
            pstmt.setString(5, rol);

            if (chkUserExtern.isSelected()) {
                pstmt.setObject(6, null);
            } else {
                AngajatModel linkedAngajat = cbUserLinkAngajat.getValue();
                pstmt.setInt(6, linkedAngajat.id);
            }

            pstmt.executeUpdate();
            refreshUsers();

            tfUserUser.clear(); tfUserPass.clear(); tfUserNume.clear(); tfUserPrenume.clear();
            cbUserLinkAngajat.setValue(null); chkUserExtern.setSelected(false);
            showInfo("Utilizator creat cu succes!");

        } catch (Exception e) { showError("Eroare (probabil username deja existent): " + e.getMessage()); }
    }

    // Buton Sterge User
    @FXML
    private void handleDeleteUser() {
        UserModel sel = usersTable.getSelectionModel().getSelectedItem();
        if(sel == null) {
            showError("Selectati un utilizator pentru stergere.");
            return;
        }

        // Check: nu te poti sterge singur
        if (UserSession.getInstance() != null && sel.id == UserSession.getInstance().getUserId()) {
            showError("Nu va puteti sterge propriul cont in timp ce sunteti logat!");
            return;
        }

        if (!showConfirmation("Sunteti sigur ca doriti sa stergeti utilizatorul " + sel.username + "?")) {
            return;
        }

        try (Connection conn = DatabaseManager.getConnection();
             // SQL: DELETE ==> Sterge user
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM Utilizatori WHERE IDUtilizator = ?")) {
            pstmt.setInt(1, sel.id);
            pstmt.executeUpdate();
            refreshUsers();
            showInfo("Utilizator sters cu succes!");
        } catch (Exception e) { showError("Eroare la stergere: " + e.getMessage()); }
    }

    // Configurare tabel Logs
    private void setupLogsTable() {
        colLogUserTried.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().usernameTried));
        colLogDate.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().date));
        colLogStatus.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().status));
        handleRefreshLogs();
    }

    // Incarcare Logs din DB
    @FXML
    private void handleRefreshLogs() {
        ObservableList<LogModel> list = FXCollections.observableArrayList();
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             // query 3 SQL: SELECT Logs DESC ==> Ultimele 50 de incercari de logare
             ResultSet rs = stmt.executeQuery("SELECT * FROM LogAcces ORDER BY DataLogin DESC LIMIT 50")) {
            while (rs.next()) {
                list.add(new LogModel(
                        rs.getInt("IDLog"), rs.getInt("IDUtilizator"), rs.getString("UsernameIncercat"),
                        rs.getTimestamp("DataLogin"), rs.getString("StatusLogin")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        logsTable.setItems(list);
    }

    // Afiseaza "Nume Prenume" in loc de obiect in ComboBox
    private void setupAngajatComboBox(ComboBox<AngajatModel> box) {
        box.setConverter(new StringConverter<AngajatModel>() {
            @Override
            public String toString(AngajatModel obj) {
                if (obj == null) return null;
                return obj.nume + " " + obj.prenume + " (" + obj.functie + ")";
            }

            @Override
            public AngajatModel fromString(String string) { return null; }
        });
    }

    // Pop-up Eroare
    private void showError(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Eroare Validare");
        alert.setHeaderText("Problema intampinata");
        alert.setContentText(msg);
        alert.showAndWait();
    }

    // Pop-up Succes
    private void showInfo(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Succes");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    // Pop-up Confirmare (DA/NU)
    private boolean showConfirmation(String msg) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmare");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }



    public static class AngajatModel {
        int id, idSupervizor;
        String nume, prenume, functie, telefon, email, numeSupervizor;
        double salariu;

        public AngajatModel(int id, String n, String p, String f, String t, String e, double s, int supId, String supName) {
            this.id=id; this.nume=n; this.prenume=p; this.functie=f; this.telefon=t;
            this.email=e; this.salariu=s; this.idSupervizor=supId; this.numeSupervizor = supName;
        }

        @Override
        public String toString() { return nume + " " + prenume; }
    }

    public static class UserModel {
        int id, idAngajat;
        String username, nume, prenume, rol, numeAngajatAsociat;

        public UserModel(int id, String u, String n, String p, String r, int ida, String angName) {
            this.id=id; this.username=u; this.nume=n; this.prenume=p; this.rol=r;
            this.idAngajat=ida; this.numeAngajatAsociat = angName;
        }
    }

    public static class LogModel {
        int id, userId; String usernameTried, date, status;
        public LogModel(int id, int uid, String userTry, Timestamp ts, String stat) {
            this.id=id; this.userId=uid; this.usernameTried=userTry;
            this.date=(ts!=null)?ts.toString():"-"; this.status=stat;
        }
    }
}