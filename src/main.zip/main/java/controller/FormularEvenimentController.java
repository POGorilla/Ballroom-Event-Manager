package controller;

import database.DatabaseManager;
import model.AngajatModel;
import model.ClientModel;
import model.SalaModel;
import model.ServiciuModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/*
 * Controller Formular Eveniment
 * Fereastra pt Adaugare/Editare eveniment + alocare resurse (angajati/servicii).
 */
public class FormularEvenimentController {
    @FXML private Label titleLabel;
    @FXML private TextField denumireField;
    @FXML private ComboBox<ClientModel> clientComboBox;
    @FXML private ComboBox<SalaModel> salaComboBox;
    @FXML private DatePicker dataInceputPicker;
    @FXML private DatePicker dataSfarsitPicker;
    @FXML private TextField nrPersoaneField;
    @FXML private ComboBox<String> statusComboBox;
    @FXML private TextField pretField;
    @FXML private Button saveButton;
    @FXML private Button cancelButton;

    @FXML private ListView<AngajatModel> availableAngajatiList;
    @FXML private ListView<AngajatModel> assignedAngajatiList;
    @FXML private Button addAngajatBtn;
    @FXML private Button removeAngajatBtn;

    @FXML private ListView<ServiciuModel> availableServiciiList;
    @FXML private ListView<ServiciuModel> assignedServiciiList;
    @FXML private Button addServiciuBtn;
    @FXML private Button removeServiciuBtn;

    private ObservableList<ServiciuModel> availableServicii = FXCollections.observableArrayList();
    private ObservableList<ServiciuModel> assignedServicii = FXCollections.observableArrayList();
    private ObservableList<ClientModel> listaClienti = FXCollections.observableArrayList();
    private ObservableList<SalaModel> listaSali = FXCollections.observableArrayList();
    private ObservableList<AngajatModel> availableAngajati = FXCollections.observableArrayList();
    private ObservableList<AngajatModel> assignedAngajati = FXCollections.observableArrayList();

    private Integer currentEventId = null; // null ==> Add, ID ==> Edit

    @FXML
    public void initialize() {
        statusComboBox.setItems(FXCollections.observableArrayList("Planificat", "Finalizat", "Anulat"));

        loadClienti();
        loadSali();
        loadAllAngajati();
        loadAllServicii();

        clientComboBox.setItems(listaClienti);
        salaComboBox.setItems(listaSali);

        availableAngajatiList.setItems(availableAngajati);
        assignedAngajatiList.setItems(assignedAngajati);

        availableServiciiList.setItems(availableServicii);
        assignedServiciiList.setItems(assignedServicii);

        // Cand schimb sala ==> Recalculez pretul total
        salaComboBox.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            recalculateTotalCost();
        });
    }

    // Setare mod (Add / Edit)
    public void initData(Integer eventId) {
        this.currentEventId = eventId;
        if (eventId == null) {
            titleLabel.setText("Adauga Eveniment Nou");
            statusComboBox.setValue("Planificat");
        } else {
            titleLabel.setText("Modifica Eveniment");
            loadEventData(eventId);
            loadAssignedAngajati(eventId);
            loadAssignedServicii(eventId);
        }
    }

    // Buton Save ==> Validare + Operatii DB
    @FXML
    private void handleSave() {
        // validare: campuri obligatorii
        if (denumireField.getText().trim().isEmpty() ||
                clientComboBox.getValue() == null ||
                salaComboBox.getValue() == null ||
                statusComboBox.getValue() == null) {

            showError("Toate campurile principale (Denumire, Client, Sala, Status) sunt obligatorii!");
            return;
        }

        // Validare date calendaristice
        LocalDate start = dataInceputPicker.getValue();
        LocalDate end = dataSfarsitPicker.getValue();

        if (start == null || end == null) {
            showError("Selectati datele de inceput si sfarsit!");
            return;
        }

        if (end.isBefore(start)) {
            showError("Data de sfarsit nu poate fi inaintea datei de inceput!");
            return;
        }

        // Validare nr persoane
        try {
            int pers = Integer.parseInt(nrPersoaneField.getText().trim());
            if (pers <= 0) {
                showError("Numarul de persoane trebuie sa fie mai mare decat 0.");
                return;
            }
        } catch (NumberFormatException e) {
            showError("Numarul de persoane invalid! Introduceti un numar intreg.");
            return;
        }

        // Validare pret
        try {
            double price = Double.parseDouble(pretField.getText().replace(",", ".").trim());
            if (price < 0) {
                showError("Pretul total nu poate fi negativ.");
                return;
            }
        } catch (NumberFormatException e) {
            showError("Pretul total este invalid! Verificati formatul.");
            return;
        }

        // queryuri db
        try {
            int eventId;
            if (currentEventId == null) {
                eventId = runInsert(); // Adaugare
            } else {
                runUpdate(); // Modificare
                eventId = currentEventId;
            }

            // Salvare relatii N:N (Angajati + Servicii)
            saveAngajati(eventId);
            saveServicii(eventId);

            showInfo("Eveniment salvat cu succes!");
            closeWindow();

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Eroare SQL: " + e.getMessage());
        }
    }

    // SQL: INSERT ==> Adauga evenimentul in tabela principala
    private int runInsert() throws SQLException {
        String sql = "INSERT INTO Evenimente (Denumire, Data_Inceput, Data_Sfarsit, Nr_Persoane, Status, IDSala, IDClient, Pret_Total) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        int generatedId = -1;

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, denumireField.getText().trim());
            pstmt.setDate(2, Date.valueOf(dataInceputPicker.getValue()));
            pstmt.setDate(3, Date.valueOf(dataSfarsitPicker.getValue()));
            pstmt.setInt(4, Integer.parseInt(nrPersoaneField.getText().trim()));
            pstmt.setString(5, statusComboBox.getValue());
            pstmt.setInt(6, salaComboBox.getValue().getId());
            pstmt.setInt(7, clientComboBox.getValue().getId());
            pstmt.setDouble(8, Double.parseDouble(pretField.getText().replace(",", ".").trim()));

            pstmt.executeUpdate();

            // Returnam ID-ul generat pt a lega angajatii/serviciile
            try (ResultSet rs = pstmt.getGeneratedKeys()) {
                if (rs.next()) generatedId = rs.getInt(1);
            }
        }
        return generatedId;
    }

    // SQL: UPDATE ==> Modifica eveniment existent
    private void runUpdate() throws SQLException {
        String sql = "UPDATE Evenimente SET Denumire = ?, Data_Inceput = ?, Data_Sfarsit = ?, Nr_Persoane = ?, " +
                "Status = ?, IDSala = ?, IDClient = ?, Pret_Total = ? WHERE IDEveniment = ?";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, denumireField.getText().trim());
            pstmt.setDate(2, Date.valueOf(dataInceputPicker.getValue()));
            pstmt.setDate(3, Date.valueOf(dataSfarsitPicker.getValue()));
            pstmt.setInt(4, Integer.parseInt(nrPersoaneField.getText().trim()));
            pstmt.setString(5, statusComboBox.getValue());
            pstmt.setInt(6, salaComboBox.getValue().getId());
            pstmt.setInt(7, clientComboBox.getValue().getId());
            pstmt.setDouble(8, Double.parseDouble(pretField.getText().replace(",", ".").trim()));
            pstmt.setInt(9, currentEventId);

            pstmt.executeUpdate();
        }
    }

    // Tranzactie SQL: Sterge vechile legaturi Angajati ==> Insereaza noile legaturi
    private void saveAngajati(int eventId) throws SQLException {
        String deleteSql = "DELETE FROM Evenimente_Angajati WHERE IDEveniment = ?";
        String insertSql = "INSERT INTO Evenimente_Angajati (IDEveniment, IDAngajat, Rol) VALUES (?, ?, ?)";

        Connection conn = DatabaseManager.getConnection();
        try {
            conn.setAutoCommit(false); // Start Tranzactie
            try (PreparedStatement deletePstmt = conn.prepareStatement(deleteSql)) {
                deletePstmt.setInt(1, eventId);
                deletePstmt.executeUpdate();
            }
            try (PreparedStatement insertPstmt = conn.prepareStatement(insertSql)) {
                for (AngajatModel angajat : assignedAngajati) {
                    insertPstmt.setInt(1, eventId);
                    insertPstmt.setInt(2, angajat.getId());
                    insertPstmt.setString(3, angajat.getFunctie());
                    insertPstmt.addBatch(); // Batch insert pt eficienta
                }
                insertPstmt.executeBatch();
            }
            conn.commit();
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
            conn.close();
        }
    }

    // Tranzactie SQL: Sterge vechile legaturi Servicii ==> Insereaza noile legaturi
    private void saveServicii(int eventId) throws SQLException {
        String deleteSql = "DELETE FROM Evenimente_Servicii WHERE IDEveniment = ?";
        String insertSql = "INSERT INTO Evenimente_Servicii (IDEveniment, IDServiciu, Cantitate) VALUES (?, ?, 1)";

        Connection conn = DatabaseManager.getConnection();
        try {
            conn.setAutoCommit(false);
            try (PreparedStatement deletePstmt = conn.prepareStatement(deleteSql)) {
                deletePstmt.setInt(1, eventId);
                deletePstmt.executeUpdate();
            }
            try (PreparedStatement insertPstmt = conn.prepareStatement(insertSql)) {
                for (ServiciuModel serviciu : assignedServicii) {
                    insertPstmt.setInt(1, eventId);
                    insertPstmt.setInt(2, serviciu.getId());
                    insertPstmt.addBatch();
                }
                insertPstmt.executeBatch();
            }
            conn.commit();
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
            conn.close();
        }
    }

    // query 11 SQL: SELECT ==> Incarcare date eveniment (pt Edit)
    private void loadEventData(int eventId) {
        String sql = "SELECT * FROM Evenimente WHERE IDEveniment = ?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, eventId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                denumireField.setText(rs.getString("Denumire"));
                dataInceputPicker.setValue(rs.getDate("Data_Inceput").toLocalDate());
                dataSfarsitPicker.setValue(rs.getDate("Data_Sfarsit").toLocalDate());
                nrPersoaneField.setText(String.valueOf(rs.getInt("Nr_Persoane")));
                statusComboBox.setValue(rs.getString("Status"));
                pretField.setText(String.valueOf(rs.getDouble("Pret_Total")));

                int idClient = rs.getInt("IDClient");
                for (ClientModel c : listaClienti) if (c.getId() == idClient) clientComboBox.setValue(c);

                int idSala = rs.getInt("IDSala");
                for (SalaModel s : listaSali) if (s.getId() == idSala) salaComboBox.setValue(s);
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }

    // query 12 SQL: SELECT ==> Incarcare liste pt dropdowns
    private void loadClienti() {
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT IDClient, Nume, Prenume FROM Clienti ORDER BY Nume, Prenume")) {
            while (rs.next()) listaClienti.add(new ClientModel(rs.getInt("IDClient"), rs.getString("Nume") + " " + rs.getString("Prenume")));
        } catch (SQLException e) { e.printStackTrace(); }
    }

    private void loadSali() {
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             // query 13
             ResultSet rs = stmt.executeQuery("SELECT IDSala, Denumire, Pret_ora FROM Sali ORDER BY Denumire")) {
            while (rs.next()) listaSali.add(new SalaModel(rs.getInt("IDSala"), rs.getString("Denumire"), rs.getDouble("Pret_ora")));
        } catch (SQLException e) { e.printStackTrace(); }
    }

    private void loadAllAngajati() {
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             // query 14
             ResultSet rs = stmt.executeQuery("SELECT IDAngajat, Nume, Prenume, Functie FROM Angajati ORDER BY Nume, Prenume")) {
            while (rs.next()) availableAngajati.add(new AngajatModel(rs.getInt("IDAngajat"), rs.getString("Nume"), rs.getString("Prenume"), rs.getString("Functie")));
        } catch (SQLException e) { e.printStackTrace(); }
    }

    private void loadAllServicii() {
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             // query 15
             ResultSet rs = stmt.executeQuery("SELECT IDServiciu, Denumire, Pret FROM Servicii ORDER BY Denumire")) {
            while (rs.next()) availableServicii.add(new ServiciuModel(rs.getInt("IDServiciu"), rs.getString("Denumire"), rs.getDouble("Pret")));
        } catch (SQLException e) { e.printStackTrace(); }
    }

    // Logica incarcare angajati deja alocati (pt Edit)
    private void loadAssignedAngajati(int eventId) {
        List<Integer> assignedIds = new ArrayList<>();
        try (Connection conn = DatabaseManager.getConnection();
             // query 16
             PreparedStatement pstmt = conn.prepareStatement("SELECT IDAngajat FROM Evenimente_Angajati WHERE IDEveniment = ?")) {
            pstmt.setInt(1, eventId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) assignedIds.add(rs.getInt("IDAngajat"));
        } catch (SQLException e) { e.printStackTrace(); }

        List<AngajatModel> toMove = new ArrayList<>();
        for (AngajatModel a : availableAngajati) if (assignedIds.contains(a.getId())) toMove.add(a);
        assignedAngajati.addAll(toMove);
        availableAngajati.removeAll(toMove);
    }

    // Logica incarcare servicii deja alocate (pt Edit)
    private void loadAssignedServicii(int eventId) {
        List<Integer> assignedIds = new ArrayList<>();
        try (Connection conn = DatabaseManager.getConnection();
             // query 17
             PreparedStatement pstmt = conn.prepareStatement("SELECT IDServiciu FROM Evenimente_Servicii WHERE IDEveniment = ?")) {
            pstmt.setInt(1, eventId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) assignedIds.add(rs.getInt("IDServiciu"));
        } catch (SQLException e) { e.printStackTrace(); }

        List<ServiciuModel> toMove = new ArrayList<>();
        for (ServiciuModel s : availableServicii) if (assignedIds.contains(s.getId())) toMove.add(s);
        assignedServicii.addAll(toMove);
        availableServicii.removeAll(toMove);
        recalculateTotalCost();
    }

    // Buton [>] Angajat
    @FXML private void handleAddAngajat() {
        AngajatModel sel = availableAngajatiList.getSelectionModel().getSelectedItem();
        if (sel != null) { availableAngajati.remove(sel); assignedAngajati.add(sel); }
    }

    // Buton [<] Angajat
    @FXML private void handleRemoveAngajat() {
        AngajatModel sel = assignedAngajatiList.getSelectionModel().getSelectedItem();
        if (sel != null) { assignedAngajati.remove(sel); availableAngajati.add(sel); }
    }

    // Buton [>] Serviciu
    @FXML private void handleAddServiciu() {
        ServiciuModel sel = availableServiciiList.getSelectionModel().getSelectedItem();
        if (sel != null) { availableServicii.remove(sel); assignedServicii.add(sel); recalculateTotalCost(); }
    }

    // Buton [<] Serviciu
    @FXML private void handleRemoveServiciu() {
        ServiciuModel sel = assignedServiciiList.getSelectionModel().getSelectedItem();
        if (sel != null) { assignedServicii.remove(sel); availableServicii.add(sel); recalculateTotalCost(); }
    }

    // Calcul automat: Pret Sala (8h) + Suma servicii
    private void recalculateTotalCost() {
        double total = 0.0;
        SalaModel selectedSala = salaComboBox.getValue();
        if (selectedSala != null) total += selectedSala.getPretOra() * 8;
        for (ServiciuModel s : assignedServicii) total += s.getPret();
        pretField.setText(String.format("%.2f", total));
    }

    @FXML private void handleCancel() { closeWindow(); }

    private void closeWindow() {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }

    private void showError(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Eroare Validare");
        alert.setHeaderText("Date invalide");
        alert.setContentText(msg);
        alert.showAndWait();
    }

    private void showInfo(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Succes");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}